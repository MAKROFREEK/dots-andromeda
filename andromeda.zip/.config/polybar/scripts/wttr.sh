#!/bin/bash

curl wttr.in/76692

